document.getElementById('registerForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
    });

    if (response.ok) {
        alert('User registered successfully');
        window.location.href = 'login.html';
    } else {
        alert('Error registering user');
    }
});

document.getElementById('loginForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
    });

    if (response.ok) {
        alert('Login successful');
        window.location.href = 'dashboard.html';
    } else {
        alert('Invalid credentials');
    }
});

document.getElementById('expenseForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const category = document.getElementById('category').value;
    const amount = document.getElementById('amount').value;

    const response = await fetch('/api/expenses', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userId: 'YOUR_USER_ID', category, amount }), // Replace YOUR_USER_ID with actual user ID
    });

    if (response.ok) {
        alert('Expense added');
        window.location.href = 'dashboard.html';
    } else {
        alert('Error adding expense');
    }
});
