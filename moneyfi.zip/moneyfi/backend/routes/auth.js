const express = require('express');
const bcrypt = require('bcrypt');
const User = require('../models/User'); // Adjust the path according to your project structure
const router = express.Router();

// GET register page
router.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/register.html')); // Serve the register page
});

// POST register
router.post('/register', async (req, res) => {
    try {
        const { username, password } = req.body;

        // Hash the password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create a new user
        const newUser = new User({
            username: username,
            password: hashedPassword
        });

        // Save user to database
        await newUser.save();
        res.status(201).send('User registered successfully!');
    } catch (error) {
        console.error('Error registering user:', error);
        res.status(500).send('Internal Server Error');
    }
});

// GET login page
router.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/login.html')); // Serve the login page
});

// POST login
router.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;

        // Find user in the database
        const user = await User.findOne({ username: username });
        if (!user) {
            return res.status(400).send('Invalid username or password');
        }

        // Check password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).send('Invalid username or password');
        }

        // Set user session
        req.session.userId = user._id;
        res.send('Login successful!');
    } catch (error) {
        console.error('Error logging in:', error);
        res.status(500).send('Internal Server Error');
    }
});

// GET logout
router.get('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            console.error('Error logging out:', err);
            return res.status(500).send('Internal Server Error');
        }
        res.redirect('/'); // Redirect to home page
    });
});

module.exports = router;
