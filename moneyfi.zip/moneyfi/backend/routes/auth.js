const express = require('express');
const router = express.Router();
const User = require('../models/User'); // Ensure this file exists

// Example register route
router.post('/register', async (req, res) => {
    // Logic for user registration
    res.send('User registered!');
});

module.exports = router;
